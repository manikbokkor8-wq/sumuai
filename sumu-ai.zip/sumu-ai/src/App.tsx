import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

type Msg = { role: "user" | "assistant"; content: string };
type Conv = { id: string; title: string; messages: Msg[]; updated: number };
const L = {
  en: { hi: "How can I help you today?", ph: "Message SUMU AI…", newChat: "New chat", search: "Search chats", send: "Send", stop: "Stop", regen: "Regenerate", copy: "Copy", rename: "Rename", del: "Delete", delAsk: "Delete this chat?", left: "messages left today", warn: "Don't share passwords or payment details.", sug: ["Explain quantum computing simply", "Write a polite email asking for leave", "Debug my JavaScript code", "বাংলায় একটি ছোট গল্প লেখো"] },
  bn: { hi: "আজ আমি কীভাবে সাহায্য করতে পারি?", ph: "SUMU AI-কে লিখুন…", newChat: "নতুন চ্যাট", search: "চ্যাট খুঁজুন", send: "পাঠান", stop: "থামান", regen: "আবার তৈরি করুন", copy: "কপি", rename: "নাম বদলান", del: "মুছুন", delAsk: "এই চ্যাট মুছবেন?", left: "টি মেসেজ আজ বাকি", warn: "পাসওয়ার্ড বা পেমেন্টের তথ্য দেবেন না।", sug: ["সহজ ভাষায় কোয়ান্টাম কম্পিউটিং বোঝাও", "ছুটির জন্য একটি ভদ্র ইমেইল লেখো", "আমার JavaScript কোড ডিবাগ করো", "Write a short story in English"] },
};
const load = (): Conv[] => { try { return JSON.parse(localStorage.getItem("sumu.convs") || "[]"); } catch { return []; } };
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

function Pre({ children }: { children?: React.ReactNode }) {
  const ref = useRef<HTMLPreElement>(null);
  const [ok, setOk] = useState(false);
  return (<div className="code"><button onClick={() => { navigator.clipboard.writeText(ref.current?.innerText || ""); setOk(true); setTimeout(() => setOk(false), 1200); }}>{ok ? "✓" : "Copy"}</button><pre ref={ref}>{children}</pre></div>);
}

export default function App() {
  const [lang, setLang] = useState<"en" | "bn">(() => (localStorage.getItem("sumu.lang") as any) || (navigator.language.startsWith("bn") ? "bn" : "en"));
  const [theme, setTheme] = useState(() => localStorage.getItem("sumu.theme") || "dark");
  const [convs, setConvs] = useState<Conv[]>(load);
  const [active, setActive] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [left, setLeft] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const abort = useRef<AbortController | null>(null);
  const end = useRef<HTMLDivElement>(null);
  const t = L[lang];
  const conv = convs.find((c) => c.id === active);

  useEffect(() => { localStorage.setItem("sumu.convs", JSON.stringify(convs)); }, [convs]);
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem("sumu.theme", theme); }, [theme]);
  useEffect(() => { localStorage.setItem("sumu.lang", lang); document.documentElement.lang = lang; }, [lang]);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [convs, busy]);

  const patch = (id: string, fn: (c: Conv) => Conv) => setConvs((cs) => cs.map((c) => (c.id === id ? fn(c) : c)));

  async function run(id: string, history: Msg[]) {
    setBusy(true); setError("");
    patch(id, (c) => ({ ...c, messages: [...history, { role: "assistant", content: "" }], updated: Date.now() }));
    const ac = new AbortController(); abort.current = ac;
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: history }), signal: ac.signal });
      if (!res.ok) { const j = await res.json().catch(() => ({})); throw new Error(j.error || `Error ${res.status}`); }
      const r = res.headers.get("x-usage-remaining"); if (r) setLeft(r);
      const rd = res.body!.getReader(), dec = new TextDecoder(); let acc = "";
      for (;;) {
        const { done, value } = await rd.read(); if (done) break;
        acc += dec.decode(value, { stream: true });
        patch(id, (c) => ({ ...c, messages: [...history, { role: "assistant", content: acc }] }));
      }
      if (!acc.trim()) throw new Error("Empty response from AI.");
    } catch (e: any) {
      if (e.name !== "AbortError") setError(e.message || "Something went wrong.");
      patch(id, (c) => ({ ...c, messages: c.messages.filter((m, i) => !(i === c.messages.length - 1 && m.role === "assistant" && !m.content)) }));
    } finally { setBusy(false); abort.current = null; }
  }

  function send(text: string) {
    text = text.trim(); if (!text || busy) return;
    setInput("");
    let id = active, history: Msg[] = [];
    if (!id || !conv) { id = uid(); setConvs((cs) => [{ id: id!, title: text.slice(0, 40), messages: [], updated: Date.now() }, ...cs]); setActive(id); }
    else history = conv.messages;
    run(id, [...history, { role: "user", content: text }]);
  }
  function regen() {
    if (!conv || busy) return;
    const ms = [...conv.messages]; while (ms.length && ms[ms.length - 1].role === "assistant") ms.pop();
    if (ms.length) run(conv.id, ms);
  }
  const rename = (c: Conv) => { const n = prompt(t.rename, c.title); if (n?.trim()) patch(c.id, (x) => ({ ...x, title: n.trim() })); };
  const del = (c: Conv) => { if (confirm(t.delAsk)) { setConvs((cs) => cs.filter((x) => x.id !== c.id)); if (active === c.id) setActive(null); } };
  const list = convs.filter((c) => c.title.toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.updated - a.updated);

  return (
    <div className="app">
      <aside className={open ? "side open" : "side"}>
        <div className="brand">SUMU AI</div>
        <button className="primary" onClick={() => { setActive(null); setOpen(false); setError(""); }}>+ {t.newChat}</button>
        <input className="field" placeholder={t.search} value={q} onChange={(e) => setQ(e.target.value)} />
        <nav>{list.map((c) => (
          <div key={c.id} className={c.id === active ? "item on" : "item"}>
            <button className="title" onClick={() => { setActive(c.id); setOpen(false); setError(""); }}>{c.title}</button>
            <button title={t.rename} onClick={() => rename(c)}>✎</button>
            <button title={t.del} onClick={() => del(c)}>🗑</button>
          </div>))}</nav>
        <div className="tools">
          <button onClick={() => setLang(lang === "en" ? "bn" : "en")}>{lang === "en" ? "বাংলা" : "English"}</button>
          <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? "☀" : "☾"}</button>
        </div>
      </aside>
      <main>
        <header><button className="burger" onClick={() => setOpen(!open)}>☰</button><span>SUMU AI</span>{left && <small>{left} {t.left}</small>}</header>
        <section className="msgs">
          {!conv || !conv.messages.length ? (
            <div className="empty"><h1>SUMU AI</h1><p>{t.hi}</p>
              <div className="sug">{t.sug.map((s) => <button key={s} onClick={() => send(s)}>{s}</button>)}</div></div>
          ) : conv.messages.map((m, i) => (
            <div key={i} className={`msg ${m.role}`}>
              {m.role === "assistant" ? <ReactMarkdown remarkPlugins={[remarkGfm]} components={{ pre: Pre as any }}>{m.content || "…"}</ReactMarkdown> : <p>{m.content}</p>}
              {m.role === "assistant" && m.content && !busy && (<div className="acts"><button onClick={() => navigator.clipboard.writeText(m.content)}>{t.copy}</button>{i === conv.messages.length - 1 && <button onClick={regen}>{t.regen}</button>}</div>)}
            </div>))}
          {error && <div className="error" role="alert">{error}</div>}
          <div ref={end} />
        </section>
        <form className="composer" onSubmit={(e) => { e.preventDefault(); send(input); }}>
          <textarea rows={1} value={input} maxLength={8000} placeholder={t.ph} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }} />
          {busy ? <button type="button" className="primary" onClick={() => abort.current?.abort()}>{t.stop}</button> : <button className="primary" disabled={!input.trim()}>{t.send}</button>}
        </form>
        <p className="note">{t.warn}</p>
      </main>
    </div>
  );
}
