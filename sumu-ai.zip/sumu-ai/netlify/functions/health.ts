export default async () =>
  Response.json({
    gemini: !!(process.env.GEMINI_API_KEY && process.env.GEMINI_MODEL),
    groq: !!(process.env.GROQ_API_KEY && process.env.GROQ_MODEL),
  });
export const config = { path: "/api/health" };
