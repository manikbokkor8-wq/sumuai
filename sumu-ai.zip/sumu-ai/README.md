# SUMU AI (v0.1)
Developer: Md. Manik. React + Vite + Netlify Functions. Guest chat with real streaming AI (Gemini, Groq fallback).

## Deploy (Netlify)
1. Upload this folder to a GitHub repo, then Netlify > Add new site > Import from Git (build: `npm run build`, publish: `dist` — already in netlify.toml).
   (Drag-and-drop of a zip does NOT build or deploy functions; use Git or `netlify deploy --build --prod` via Netlify CLI.)
2. Site configuration > Environment variables: set `GEMINI_API_KEY` + `GEMINI_MODEL` (key: aistudio.google.com/apikey; use a model ID from its current list), optionally `GROQ_API_KEY` + `GROQ_MODEL` (console.groq.com), optionally `USAGE_GUEST_DAILY_LIMIT` (default 10).
3. Redeploy. Check `/api/health`.

## Included
Streaming chat, history/rename/delete/search (local), Markdown+tables, code copy, regenerate, stop, dark/light, English/Bengali UI, server-side per-IP daily limit, retry/backoff/timeout/fallback, developer identity in server-side system prompt.
## Not yet built
Supabase accounts/RLS, admin dashboard, file/image upload, web search, voice, image generation, tool calling, math rendering, syntax highlighting, privacy page.
